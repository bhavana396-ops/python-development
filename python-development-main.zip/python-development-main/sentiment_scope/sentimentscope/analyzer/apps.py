from django.apps import AppConfig


class AnalyzerConfig(AppConfig):
    name = 'analyzer'
