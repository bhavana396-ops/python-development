from flask import Flask, render_template, request, redirect, session
from flask_mysqldb import MySQL
import numpy as np, pickle, os
from sklearn.linear_model import LogisticRegression

app = Flask(__name__)
app.secret_key = "stresskey"

# ---------- MySQL Config ----------
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'bhavana'
app.config['MYSQL_DB'] = 'exam_stress'
mysql = MySQL(app)

# ---------- ML Model ----------
import numpy as np
from sklearn.linear_model import LogisticRegression
import pickle

# Train model every time (safe & simple)
X = np.array([[2,3,4],[8,8,9],[5,6,7],[1,2,2]])
y = [0,2,1,0]  # 0=Low,1=Medium,2=High

model = LogisticRegression()
model.fit(X,y)

pickle.dump(model, open("model.pkl","wb"))
model = pickle.load(open("model.pkl","rb"))


# ---------- Routes ----------
@app.route("/")
def home():
    return render_template("home.html")


@app.route("/login", methods=["GET","POST"])
def login():
    if request.method=="POST":
        u=request.form["u"]
        p=request.form["p"]
        cur=mysql.connection.cursor()
        cur.execute("SELECT * FROM users WHERE username=%s AND password=%s",(u,p))
        if cur.fetchone():
            session["user"]=u
            return redirect("/dashboard")
    return render_template("login.html")


@app.route("/register", methods=["GET","POST"])
def register():
    if request.method=="POST":
        u=request.form["u"]
        p=request.form["p"]
        cur=mysql.connection.cursor()
        cur.execute("INSERT INTO users(username,password) VALUES(%s,%s)",(u,p))
        mysql.connection.commit()
        return redirect("/login")
    return render_template("register.html")


@app.route("/dashboard", methods=["GET","POST"])
def dashboard():
    if "user" not in session:
        return redirect("/login")

    prediction = None

    if request.method == "POST":
        sleep = int(request.form["sleep"])
        study = int(request.form["study"])
        pressure = int(request.form["pressure"])

        # -------- CUSTOM LOGIC ----------
        if sleep <= 4 and study >= 7 and pressure >= 7:
            prediction = "High Stress"
        elif sleep <= 5 and (study >= 6 or pressure >= 6):
            prediction = "Medium Stress"
        else:
            prediction = "Low Stress"
        # --------------------------------

        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO stress(username, level) VALUES(%s,%s)",
                    (session["user"], prediction))
        mysql.connection.commit()

    return render_template("dashboard.html", prediction=prediction)




@app.route("/logout")
def logout():
    session.clear()
    return redirect("/")


if __name__=="__main__":
    app.run(debug=True)
